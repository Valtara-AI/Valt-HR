module.exports = {
  apps: [{
    name: 'hr-suite',
    cwd: '/home/ubuntu/hr-suite',
    script: 'npm',
    args: 'start',
    instances: 2,
    exec_mode: 'cluster',
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 3000
    },
    error_file: '/home/ubuntu/logs/hr-suite-error.log',
    out_file: '/home/ubuntu/logs/hr-suite-out.log',
    log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
    merge_logs: true,
    time: true
  }]
};
